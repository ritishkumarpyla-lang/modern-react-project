import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { Search, Filter, Mail, Phone, ExternalLink, GraduationCap } from 'lucide-react';

const Candidates = () => {
    const { data } = useData();
    const [searchTerm, setSearchTerm] = useState('');

    const getStatusBadge = (status) => {
        const baseClasses = "px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border";
        switch (status) {
            case 'Completed':
            case 'Shortlisted':
            case 'Hired':
                return `${baseClasses} bg-emerald-50 text-emerald-700 border-emerald-100`;
            case 'In Progress':
            case 'Scheduled':
                return `${baseClasses} bg-blue-50 text-blue-700 border-blue-100`;
            case 'Pending':
            case 'Candidate Sourced':
                return `${baseClasses} bg-slate-50 text-slate-600 border-slate-200`;
            default:
                return `${baseClasses} bg-slate-50 text-slate-600 border-slate-200`;
        }
    };

    const filteredCandidates = data.candidates.filter(can =>
        can.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        can.email.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900">Candidates</h1>
                </div>
                <div className="flex gap-2">
                    <button className="flex items-center gap-2 bg-white border border-slate-200 text-slate-600 px-4 py-2 rounded-xl font-bold hover:bg-slate-50 transition-all">
                        <Filter size={18} />
                        <span>Filter</span>
                    </button>
                    <button className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-5 py-2.5 rounded-xl font-bold transition-all shadow-lg shadow-primary-500/20">
                        <GraduationCap size={20} />
                        <span>Import Candidates</span>
                    </button>
                </div>
            </div>

            <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input
                    type="text"
                    placeholder="Search candidates by name, email, or project..."
                    className="w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-4 focus:ring-primary-500/10 focus:border-primary-500 transition-all shadow-sm"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                <table className="w-full text-left border-collapse">
                    <thead>
                        <tr className="bg-slate-50 border-b border-slate-200">
                            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Candidate</th>
                            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Project</th>
                            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Training Status</th>
                            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Hiring Status</th>
                            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {filteredCandidates.map((can) => (
                            <tr key={can.id} className="hover:bg-slate-50/50 transition-colors group">
                                <td className="px-6 py-5">
                                    <div>
                                        <p className="font-bold text-slate-900">{can.name}</p>
                                        <div className="flex items-center gap-3 mt-1 text-xs text-slate-400 font-medium">
                                            <span className="flex items-center gap-1"><Mail size={12} /> {can.email}</span>
                                            <span className="flex items-center gap-1"><Phone size={12} /> {can.phone}</span>
                                        </div>
                                    </div>
                                </td>
                                <td className="px-6 py-5">
                                    <div className="inline-flex items-center gap-2 px-2 py-1 bg-slate-100 rounded-md">
                                        <span className="text-xs font-bold text-slate-600">{can.projectId}</span>
                                    </div>
                                </td>
                                <td className="px-6 py-5">
                                    <div className="flex flex-col gap-1">
                                        <span className={getStatusBadge(can.trainingStatus)}>{can.trainingStatus}</span>
                                        <span className="text-[10px] font-bold text-slate-400 pl-1">Cert: {can.certificationStatus}</span>
                                    </div>
                                </td>
                                <td className="px-6 py-5">
                                    <span className={getStatusBadge(can.hiringStatus)}>{can.hiringStatus}</span>
                                </td>
                                <td className="px-6 py-5 text-right text-transparent group-hover:text-primary-600 transition-colors">
                                    <button className="p-2 hover:bg-primary-50 rounded-lg transition-colors">
                                        <ExternalLink size={18} />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default Candidates;
