import React from 'react';
import { useData } from '../../context/DataContext';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { Download, Filter, TrendingUp, Users, BookOpen, CheckCircle } from 'lucide-react';

const Reports = () => {
    const { data } = useData();

    const hiringProgressData = [
        { name: 'Sourced', value: 45 },
        { name: 'Training', value: 32 },
        { name: 'Interview', value: 18 },
        { name: 'Hired', value: 32 },
    ];

    const trainingSuccessData = [
        { name: 'Logic', success: 85, fail: 15 },
        { name: 'Business', success: 92, fail: 8 },
        { name: 'Computer', success: 78, fail: 22 },
    ];

    const COLORS = ['#0ea5e9', '#6366f1', '#f59e0b', '#10b981'];

    return (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-8">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900">Analytics & Reports</h1>
                    <p className="text-slate-500 mt-1">Deep dive into RRTech Corp performance metrics.</p>
                </div>
                <button className="flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white px-5 py-2.5 rounded-xl font-bold transition-all shadow-lg shadow-slate-900/10">
                    <Download size={18} />
                    <span>Export PDF</span>
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-2xl border border-slate-200">
                    <div className="flex items-center gap-3 text-blue-600 mb-2">
                        <TrendingUp size={20} />
                        <span className="text-xs font-black uppercase tracking-widest">Growth</span>
                    </div>
                    <p className="text-2xl font-black text-slate-900">+12%</p>
                    <p className="text-xs font-medium text-slate-500">Candidate placement vs last month</p>
                </div>
                <div className="bg-white p-6 rounded-2xl border border-slate-200">
                    <div className="flex items-center gap-3 text-emerald-600 mb-2">
                        <CheckCircle size={20} />
                        <span className="text-xs font-black uppercase tracking-widest">Success</span>
                    </div>
                    <p className="text-2xl font-black text-slate-900">89.4%</p>
                    <p className="text-xs font-medium text-slate-500">Average training completion rate</p>
                </div>
                <div className="bg-white p-6 rounded-2xl border border-slate-200">
                    <div className="flex items-center gap-3 text-primary-600 mb-2">
                        <BookOpen size={20} />
                        <span className="text-xs font-black uppercase tracking-widest">Efficiency</span>
                    </div>
                    <p className="text-2xl font-black text-slate-900">14 Days</p>
                    <p className="text-xs font-medium text-slate-500">Avg time from source to hire</p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-white p-8 rounded-2xl border border-slate-200">
                    <h3 className="text-lg font-bold text-slate-900 mb-8">Pipeline Distribution</h3>
                    <div className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie data={hiringProgressData} innerRadius={60} outerRadius={100} paddingAngle={5} dataKey="value">
                                    {hiringProgressData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip />
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                    <div className="grid grid-cols-2 gap-4 mt-4">
                        {hiringProgressData.map((d, i) => (
                            <div key={i} className="flex items-center gap-2">
                                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i] }}></div>
                                <span className="text-xs font-bold text-slate-600">{d.name}: {d.value}</span>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="bg-white p-8 rounded-2xl border border-slate-200">
                    <h3 className="text-lg font-bold text-slate-900 mb-8">Training Efficiency by Type</h3>
                    <div className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={trainingSuccessData} layout="vertical">
                                <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#f1f5f9" />
                                <XAxis type="number" hide />
                                <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                                <Tooltip />
                                <Bar dataKey="success" stackId="a" fill="#0ea5e9" radius={[0, 0, 0, 0]} barSize={20} />
                                <Bar dataKey="fail" stackId="a" fill="#f1f5f9" radius={[0, 4, 4, 0]} barSize={20} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                    <div className="flex gap-4 mt-6">
                        <div className="flex items-center gap-2">
                            <div className="w-12 h-2 bg-primary-500 rounded-full"></div>
                            <span className="text-[10px] font-black uppercase text-slate-400">Completion %</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <div className="w-12 h-2 bg-slate-100 rounded-full"></div>
                            <span className="text-[10px] font-black uppercase text-slate-400">Drop-off %</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Reports;
