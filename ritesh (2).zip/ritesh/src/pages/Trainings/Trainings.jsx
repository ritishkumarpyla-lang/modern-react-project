import React from 'react';
import { useData } from '../../context/DataContext';
import { BookOpen, Award, CreditCard, Clock, Plus, Zap } from 'lucide-react';

const Trainings = () => {
    const { data } = useData();

    const getPaymentStyle = (type) => {
        if (type.includes('RRTech')) return 'bg-primary-100 text-primary-700';
        if (type.includes('Client')) return 'bg-indigo-100 text-indigo-700';
        return 'bg-amber-100 text-amber-700';
    };

    return (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900">Training Programs</h1>
                </div>
                <button className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-5 py-2.5 rounded-xl font-bold transition-all shadow-lg shadow-primary-500/20">
                    <Plus size={20} />
                    <span>New Program</span>
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {data.trainings.map((training) => (
                    <div key={training.id} className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow group">
                        <div className="p-6">
                            <div className="flex justify-between items-start mb-6">
                                <div className="w-12 h-12 bg-primary-100 text-primary-600 rounded-xl flex items-center justify-center">
                                    <BookOpen size={24} />
                                </div>
                                {training.certRequired === 'Yes' && (
                                    <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 text-emerald-600 rounded-full">
                                        <Award size={14} />
                                        <span className="text-[10px] font-black uppercase tracking-tight">Certified</span>
                                    </div>
                                )}
                            </div>

                            <h3 className="text-xl font-bold text-slate-900 mb-2">{training.type}</h3>

                            <div className="space-y-4">
                                <div className="flex items-center justify-between py-2 border-b border-slate-50">
                                    <div className="flex items-center gap-2 text-slate-500">
                                        <Clock size={16} />
                                        <span className="text-sm font-medium">Duration</span>
                                    </div>
                                    <span className="text-sm font-bold text-slate-900">{training.duration}</span>
                                </div>

                                <div className="flex items-center justify-between py-2 border-b border-slate-50">
                                    <div className="flex items-center gap-2 text-slate-500">
                                        <CreditCard size={16} />
                                        <span className="text-sm font-medium">Payment</span>
                                    </div>
                                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${getPaymentStyle(training.paymentType)}`}>
                                        {training.paymentType}
                                    </span>
                                </div>

                                <div className="flex items-center justify-between py-2 border-b border-slate-50">
                                    <div className="flex items-center gap-2 text-slate-500">
                                        <Zap size={16} />
                                        <span className="text-sm font-medium">Provider ID</span>
                                    </div>
                                    <span className="text-sm font-bold text-slate-900">{training.vendorId}</span>
                                </div>
                            </div>
                        </div>

                        <div className="p-4 bg-slate-50 flex items-center justify-between">
                            <p className="text-[10px] font-bold text-slate-400">ID: {training.id}</p>
                            <button className="text-primary-600 font-bold text-xs hover:text-primary-700 transition-colors">Edit Config</button>
                        </div>
                    </div>
                ))}

                {/* Action Card */}
                <div className="border-2 border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center p-8 hover:bg-slate-50 transition-colors cursor-pointer group">
                    <div className="w-12 h-12 bg-white border border-slate-100 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                        <Plus size={24} className="text-slate-400 group-hover:text-primary-600" />
                    </div>
                    <p className="font-bold text-slate-500 group-hover:text-primary-600 transition-colors">Add Custom Track</p>
                </div>
            </div>
        </div>
    );
};

export default Trainings;
