import React from 'react';
import { useData } from '../../context/DataContext';
import { Users, Briefcase, GraduationCap, CheckCircle, Clock } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const StatCard = ({ title, value, icon: Icon, color }) => (
    <div className="glass-card p-6 rounded-2xl flex items-center justify-between border-slate-200">
        <div>
            <p className="text-slate-500 font-medium text-sm mb-1">{title}</p>
            <h3 className="text-3xl font-bold text-slate-900">{value}</h3>
        </div>
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${color} bg-opacity-10 text-opacity-100`}>
            <Icon size={24} className={color.replace('bg-', 'text-')} />
        </div>
    </div>
);

const Dashboard = () => {
    const { data } = useData();
    const { stats } = data;

    const barData = [
        { name: 'Jan', count: 12 },
        { name: 'Feb', count: 19 },
        { name: 'Mar', count: 15 },
        { name: 'Apr', count: 22 },
        { name: 'May', count: 30 },
    ];

    const pieData = [
        { name: 'Shortlisted', value: stats.shortlistedCandidates, color: '#38bdf8' },
        { name: 'Hired', value: stats.hiredCandidates, color: '#10b981' },
        { name: 'In Training', value: stats.candidatesInTraining, color: '#f59e0b' },
    ];

    return (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-8">
            <div>
                <h1 className="text-3xl font-bold text-slate-900">Experience Dashboard</h1>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <StatCard title="Total Clients" value={stats.totalClients} icon={Users} color="bg-blue-500" />
                <StatCard title="Active Projects" value={stats.activeProjects} icon={Briefcase} color="bg-primary-500" />
                <StatCard title="Training Programs" value={data.trainings.length} icon={Clock} color="bg-indigo-500" />
                <StatCard title="Candidates in Training" value={stats.candidatesInTraining} icon={GraduationCap} color="bg-orange-500" />
                <StatCard title="Shortlisted Candidates" value={stats.shortlistedCandidates} icon={CheckCircle} color="bg-emerald-500" />
                <StatCard title="Hired Candidates" value={stats.hiredCandidates} icon={CheckCircle} color="bg-green-600" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="glass-card p-8 rounded-2xl border-slate-200">
                    <h3 className="text-lg font-bold text-slate-900 mb-6 font-primary text-secondary-900 antialiased leading-tight tracking-tight">Hirings Trend</h3>
                    <div className="h-[300px] w-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={barData}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} dy={10} />
                                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} />
                                <Tooltip
                                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                                    cursor={{ fill: '#f1f5f9' }}
                                />
                                <Bar dataKey="count" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                <div className="glass-card p-8 rounded-2xl border-slate-200">
                    <h3 className="text-lg font-bold text-slate-900 mb-6">Candidate Distribution</h3>
                    <div className="h-[300px] w-full flex items-center justify-center">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={pieData}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={80}
                                    outerRadius={100}
                                    paddingAngle={5}
                                    dataKey="value"
                                >
                                    {pieData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={entry.color} />
                                    ))}
                                </Pie>
                                <Tooltip />
                            </PieChart>
                        </ResponsiveContainer>
                        <div className="absolute flex flex-col items-center">
                            <span className="text-3xl font-extrabold text-slate-900">{stats.hiredCandidates + stats.shortlistedCandidates + stats.candidatesInTraining}</span>
                            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Total Active</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
