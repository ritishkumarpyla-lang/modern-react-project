import React, { useCallback, useState } from 'react';
import ReactFlow, {
    addEdge,
    Background,
    Controls,
    MiniMap,
    useNodesState,
    useEdgesState,
    Panel,
    MarkerType
} from 'reactflow';
import 'reactflow/dist/style.css';
import { Save, Play, RotateCcw, Plus, Trash2 } from 'lucide-react';

const initialNodes = [
    { id: '1', type: 'input', data: { label: 'Start' }, position: { x: 250, y: 0 }, style: { background: '#0ea5e9', color: '#fff', fontWeight: 'bold', borderRadius: '12px', border: 'none', padding: '10px 20px' } },
];

const initialEdges = [];

const nodeTypes = {}; // Custom nodes can be added here

const WorkflowBuilder = () => {
    const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
    const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
    const [workflowName, setWorkflowName] = useState('New Project Workflow');

    const onConnect = useCallback((params) => setEdges((eds) => addEdge({
        ...params,
        animated: true,
        style: { stroke: '#0ea5e9', strokeWidth: 2 },
        markerEnd: { type: MarkerType.ArrowClosed, color: '#0ea5e9' }
    }, eds)), [setEdges]);

    const addNode = (label, type = 'default') => {
        const id = `${nodes.length + 1}`;
        const newNode = {
            id,
            type,
            data: { label: label },
            position: { x: Math.random() * 400, y: Math.random() * 400 },
            style: {
                background: label.includes('?') ? '#f59e0b' : '#fff',
                color: label.includes('?') ? '#fff' : '#1e293b',
                fontWeight: '600',
                borderRadius: '12px',
                border: '2px solid #e2e8f0',
                boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                padding: '10px 20px',
                fontSize: '12px'
            }
        };
        setNodes((nds) => nds.concat(newNode));
    };

    const nodeLibrary = [
        'Training Required?',
        'Select Training Type',
        'Assign Vendor',
        'Payment Decision',
        'Certification Required?',
        'Training Completed',
        'Interview',
        'Shortlist',
        'Offer Letter',
        'Hire'
    ];

    return (
        <div className="h-[calc(100vh-400px)] mb-12 animate-in fade-in duration-500">
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900">Workflow Builder</h1>
                    <input
                        type="text"
                        value={workflowName}
                        onChange={(e) => setWorkflowName(e.target.value)}
                        className="text-slate-500 bg-transparent border-none focus:ring-0 p-0 font-medium cursor-pointer hover:text-primary-600 transition-colors"
                    />
                </div>
                <div className="flex gap-3">
                    <button
                        onClick={() => { setNodes(initialNodes); setEdges(initialEdges); }}
                        className="flex items-center gap-2 px-4 py-2 text-slate-600 font-bold hover:bg-slate-100 rounded-xl transition-all"
                    >
                        <RotateCcw size={18} /> Reset
                    </button>
                    <button className="flex items-center gap-2 px-5 py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-xl font-bold shadow-lg shadow-primary-500/20 transition-all">
                        <Save size={18} /> Save Workflow
                    </button>
                </div>
            </div>

            <div className="flex gap-6 h-full">
                {/* Sidebar Library */}
                <div className="w-64 flex-shrink-0 bg-white rounded-2xl border border-slate-200 p-4 overflow-y-auto">
                    <h3 className="text-xs font-black uppercase text-slate-400 tracking-widest mb-4">Node Library</h3>
                    <div className="space-y-2">
                        {nodeLibrary.map((label) => (
                            <div
                                key={label}
                                onClick={() => addNode(label)}
                                className="p-3 bg-slate-50 border border-slate-100 rounded-xl cursor-move hover:border-primary-300 hover:bg-primary-50 transition-all group"
                            >
                                <div className="flex items-center justify-between">
                                    <span className="text-xs font-bold text-slate-700 group-hover:text-primary-700">{label}</span>
                                    <Plus size={14} className="text-slate-300 group-hover:text-primary-500" />
                                </div>
                            </div>
                        ))}
                    </div>

                    <div className="mt-8 pt-6 border-t border-slate-100">
                        <div className="p-4 bg-primary-50 rounded-xl">
                            <p className="text-[10px] font-bold text-primary-700 uppercase mb-1">Tip</p>
                            <p className="text-[10px] text-primary-600 leading-relaxed font-medium">Click a node to add it to the canvas, then drag from the circles to connect them.</p>
                        </div>
                    </div>
                </div>

                {/* Canvas */}
                <div className="flex-1 bg-white rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden">
                    <ReactFlow
                        nodes={nodes}
                        edges={edges}
                        onNodesChange={onNodesChange}
                        onEdgesChange={onEdgesChange}
                        onConnect={onConnect}
                        fitView
                    >
                        <Background color="#cbd5e1" gap={20} />
                        <Controls />
                        <MiniMap
                            nodeStrokeColor={(n) => n.style?.background || '#eee'}
                            nodeColor={(n) => n.style?.background || '#fff'}
                            className="rounded-xl border border-slate-100"
                        />
                        <Panel position="bottom-right" className="bg-white/80 backdrop-blur-md p-2 rounded-lg border border-slate-100 flex gap-2">
                            <button className="p-2 text-slate-400 hover:text-emerald-500 transition-colors"><Play size={20} /></button>
                            <button className="p-2 text-slate-400 hover:text-red-500 transition-colors"><Trash2 size={20} /></button>
                        </Panel>
                    </ReactFlow>
                </div>
            </div>
        </div>
    );
};

export default WorkflowBuilder;
