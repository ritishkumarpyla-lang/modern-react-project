import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { KeyRound, ShieldCheck, UserCircle } from 'lucide-react';
import loginBg from '../../assets/login-bg.png';

const Login = () => {
    const [role, setRole] = useState('Account Manager');
    const { login } = useAuth();
    const navigate = useNavigate();

    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('12345');
    const [error, setError] = useState('');

    const handleLogin = (e) => {
        e.preventDefault();
        if (password === '12345') {
            setError('');
            login(role, username);
            navigate('/');
        } else {
            setError('Invalid access password. Please try again.');
        }
    };

    return (
        <div
            className="min-h-screen flex items-center justify-center bg-slate-900 overflow-hidden relative"
            style={{
                backgroundImage: `url(${loginBg})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
            }}
        >
            <div className="absolute inset-0 bg-slate-900/20 backdrop-blur-[2px]"></div>

            <div className="w-full max-w-md p-8 bg-white/70 backdrop-blur-xl border border-white/40 rounded-3xl z-10 mx-4 shadow-2xl">
                <div className="text-center mb-8">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-600 rounded-2xl text-white mb-4 shadow-lg shadow-primary-500/30">
                        <ShieldCheck size={32} />
                    </div>
                    <h1 className="text-3xl font-bold text-slate-900">RRTech</h1>
                </div>

                {error && (
                    <div className="mb-6 p-3 bg-red-50 border border-red-200 text-red-600 text-sm font-medium rounded-xl animate-in slide-in-from-top-2 duration-300">
                        {error}
                    </div>
                )}

                <form onSubmit={handleLogin} className="space-y-6">
                    <div className="space-y-2">
                        <label className="text-sm font-semibold text-slate-700 ml-1">Select Your Role</label>
                        <div className="grid grid-cols-2 gap-3">
                            <button
                                type="button"
                                onClick={() => setRole('Account Manager')}
                                className={`flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all ${role === 'Account Manager'
                                    ? 'border-primary-500 bg-primary-50 text-primary-600'
                                    : 'border-slate-100 bg-slate-50 text-slate-500 hover:border-slate-200'
                                    }`}
                            >
                                <ShieldCheck size={24} className="mb-2" />
                                <span className="text-xs font-bold uppercase tracking-tight">Manager</span>
                            </button>
                            <button
                                type="button"
                                onClick={() => setRole('Client')}
                                className={`flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all ${role === 'Client'
                                    ? 'border-primary-500 bg-primary-50 text-primary-600'
                                    : 'border-slate-100 bg-slate-50 text-slate-500 hover:border-slate-200'
                                    }`}
                            >
                                <UserCircle size={24} className="mb-2" />
                                <span className="text-xs font-bold uppercase tracking-tight">Client</span>
                            </button>
                        </div>
                    </div>

                    <div className="space-y-4 pt-2">
                        <div className="relative">
                            <UserCircle className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                            <input
                                type="text"
                                placeholder="Username / Email"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                className="w-full pl-10 pr-4 py-3 bg-white/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 transition-all font-medium"
                                required
                            />
                        </div>
                        <div className="relative">
                            <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                            <input
                                type="password"
                                placeholder="Access Password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="w-full pl-10 pr-4 py-3 bg-white/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 transition-all font-medium"
                                required
                            />
                        </div>
                    </div>

                    <button
                        type="submit"
                        className="w-full py-4 bg-primary-600 hover:bg-primary-700 text-white rounded-xl font-bold text-lg shadow-lg shadow-primary-600/20 transition-all hover:-translate-y-0.5"
                    >
                        Sign In
                    </button>
                </form>

                <div className="mt-8 pt-6 border-t border-slate-200/50 text-center">
                    <p className="text-slate-400 text-sm">© 2026 RRTech Corp. All rights reserved.</p>
                </div>
            </div>
        </div>
    );
};

export default Login;
