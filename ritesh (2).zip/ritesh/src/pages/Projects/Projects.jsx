import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { Plus, Search, Calendar, Briefcase, ChevronRight, AlertCircle, CheckCircle2, X } from 'lucide-react';
import ReactFlow, { Background, Controls } from 'reactflow';
import 'reactflow/dist/style.css';

const Projects = () => {
    const { data } = useData();
    const { user } = useAuth();
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedProject, setSelectedProject] = useState(null);

    const filteredProjects = data.projects.filter(project =>
        project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        project.clientName.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const getStatusStyle = (status) => {
        switch (status) {
            case 'In Progress': return 'bg-blue-100 text-blue-700';
            case 'Planning': return 'bg-amber-100 text-amber-700';
            case 'Completed': return 'bg-emerald-100 text-emerald-700';
            default: return 'bg-slate-100 text-slate-700';
        }
    };

    const isAM = user?.role === 'Account Manager';

    // Basic mock workflow for visualization
    const initialNodes = [
        { id: '1', data: { label: 'Start' }, position: { x: 50, y: 50 }, type: 'input' },
        { id: '2', data: { label: 'Training Required?' }, position: { x: 50, y: 150 } },
        { id: '3', data: { label: 'Assign Vendor' }, position: { x: 50, y: 250 } },
        { id: '4', data: { label: 'Hire' }, position: { x: 50, y: 350 }, type: 'output' },
    ];
    const initialEdges = [
        { id: 'e1-2', source: '1', target: '2', animated: true },
        { id: 'e2-3', source: '2', target: '3', animated: true },
        { id: 'e3-4', source: '3', target: '4', animated: true },
    ];

    return (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900">Projects</h1>
                </div>
                {isAM && (
                    <button className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-5 py-2.5 rounded-xl font-bold transition-all shadow-lg shadow-primary-500/20">
                        <Plus size={20} />
                        <span>Create Project</span>
                    </button>
                )}
            </div>

            <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input
                    type="text"
                    placeholder="Search projects by name or client..."
                    className="w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-4 focus:ring-primary-500/10 focus:border-primary-500 transition-all shadow-sm"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredProjects.map((project) => (
                    <div key={project.id} className="glass-card p-6 rounded-2xl border-slate-200 hover:border-primary-300 transition-all group overflow-hidden relative">
                        <div className="absolute top-[-10px] right-[-10px] opacity-[0.03] group-hover:scale-110 transition-transform duration-500">
                            <Briefcase size={120} />
                        </div>

                        <div className="flex justify-between items-start mb-4">
                            <div>
                                <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${getStatusStyle(project.status)}`}>
                                    {project.status}
                                </span>
                                <h3 className="text-xl font-bold text-slate-900 mt-2">{project.name}</h3>
                                <p className="text-slate-500 font-medium text-sm flex items-center gap-1.5">
                                    <Calendar size={14} /> Started: {project.startDate}
                                </p>
                            </div>
                            <div className="text-right">
                                <p className="text-sm font-bold text-primary-600">{project.clientName}</p>
                                <p className={`text-xs font-bold px-2 py-0.5 rounded-md inline-block mt-1 ${project.type === 'On-site' ? 'bg-indigo-50 text-indigo-600' : 'bg-slate-50 text-slate-600'}`}>
                                    {project.type}
                                </p>
                            </div>
                        </div>

                        <div className="mt-6 pt-6 border-t border-slate-100 flex items-center justify-between">
                            <div className="flex items-center gap-4">
                                <div className="flex flex-col">
                                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Training</span>
                                    <div className="flex items-center gap-1.5 mt-0.5">
                                        {project.trainingRequired === 'Yes' ? (
                                            <CheckCircle2 size={16} className="text-emerald-500" />
                                        ) : (
                                            <AlertCircle size={16} className="text-slate-300" />
                                        )}
                                        <span className="text-sm font-bold text-slate-700">{project.trainingRequired === 'Yes' ? 'Required' : 'Not Required'}</span>
                                    </div>
                                </div>
                                {project.type === 'On-site' && (
                                    <div className="flex flex-col border-l border-slate-100 pl-4">
                                        <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Validation</span>
                                        <span className="text-sm font-bold text-orange-600 mt-0.5 whitespace-nowrap">Min 2 Trainings</span>
                                    </div>
                                )}
                            </div>

                            <button
                                onClick={() => setSelectedProject(project)}
                                className="flex items-center gap-1 text-primary-600 font-bold text-sm hover:translate-x-1 transition-transform"
                            >
                                View Workflow <ChevronRight size={16} />
                            </button>
                        </div>
                    </div>
                ))}
            </div>

            {/* Workflow Visualization Modal */}
            {selectedProject && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
                    <div className="bg-white w-full max-w-4xl h-[80vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200">
                        <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                            <div>
                                <h2 className="text-2xl font-bold text-slate-900">{selectedProject.name}</h2>
                                <p className="text-slate-500 text-sm font-medium">Standard Project Workflow Execution Path</p>
                            </div>
                            <button onClick={() => setSelectedProject(null)} className="p-2 bg-white border border-slate-200 text-slate-400 hover:text-slate-900 rounded-xl transition-colors">
                                <X size={20} />
                            </button>
                        </div>

                        <div className="flex-1 relative">
                            <ReactFlow
                                nodes={initialNodes}
                                edges={initialEdges}
                                fitView
                                nodesDraggable={false}
                                nodesConnectable={false}
                                elementsSelectable={false}
                                panOnDrag={false}
                                zoomOnScroll={false}
                            >
                                <Background color="#f1f5f9" />
                            </ReactFlow>

                            <div className="absolute bottom-6 left-6 right-6 flex justify-between items-end pointer-events-none">
                                <div className="p-4 bg-white/80 backdrop-blur border border-slate-100 rounded-2xl shadow-lg pointer-events-auto">
                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Live Insights</p>
                                    <div className="flex items-center gap-6">
                                        <div className="flex flex-col">
                                            <span className="text-xl font-black text-slate-900">84%</span>
                                            <span className="text-[10px] font-bold text-emerald-500 uppercase">Efficiency</span>
                                        </div>
                                        <div className="flex flex-col border-l border-slate-100 pl-6">
                                            <span className="text-xl font-black text-slate-900">3d</span>
                                            <span className="text-[10px] font-bold text-primary-500 uppercase">Avg Delay</span>
                                        </div>
                                    </div>
                                </div>

                                <div className="bg-slate-900 text-white px-6 py-3 rounded-2xl shadow-xl font-bold text-sm flex items-center gap-2 pointer-events-auto cursor-help">
                                    <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                                    Direct Visualization
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Projects;
