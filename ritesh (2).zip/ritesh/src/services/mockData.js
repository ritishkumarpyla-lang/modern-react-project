export const mockData = {
    stats: {
        totalClients: 3,
        activeProjects: 4,
        trainingsInProgress: 3,
        candidatesInTraining: 4,
        shortlistedCandidates: 2,
        hiredCandidates: 2,
    },
    roles: {
        ACCOUNT_MANAGER: 'Account Manager',
        CLIENT: 'Client',
    },
    clients: [
        { id: 'c1', name: 'Global Tech', company: 'Global Tech Solutions', contact: 'Chandra', email: 'chandra@globaltech.com', phone: '987-456-5467', address: 'Madhapur Hyderabad' },
        { id: 'c2', name: 'InnoCorp', company: 'InnoCorp Inc', contact: 'Prakash', email: 'prakash@innocorp.com', phone: '987-654-3210', address: 'Kondapur Hyderabad' },
        { id: 'c3', name: 'Wipro', company: 'Wipro In', contact: 'Ravi', email: 'ravi@wipro.com', phone: '630-654-3210', address: 'Marthali Bangalore' },

    ],
    projects: [
        { id: 'p1', name: 'Frontend Migration', clientId: 'c1', clientName: 'Global Tech', type: 'On-site', trainingRequired: 'Yes', startDate: '2024-03-01', status: 'In Progress' },
        { id: 'p2', name: 'Cloud Infrastructure', clientId: 'c2', clientName: 'InnoCorp', type: 'Off-site', trainingRequired: 'No', startDate: '2024-03-15', status: 'Planning' },
        { id: 'p3', name: 'Cloud Infrastructure', clientId: 'c2', clientName: 'Wipro', type: 'Off-site', trainingRequired: 'Yes', startDate: '2024-05-25', status: 'Planning' },

    ],
    vendors: [
        { id: 'v1', name: 'SkillSet Academy', trainings: ['Computer Skills', 'Business Skills'], email: 'contact@skillset.com', phone: '987-654-3210', location: 'New Delhi' },
        { id: 'v2', name: 'Logic Masters', trainings: ['Logic Skills'], email: 'info@logicmasters.com', phone: '789-545-3456', location: 'Bangalore' },
    ],
    candidates: [
        { id: 'can1', name: 'Naveen', email: 'naveen@rrtech.com', phone: '6509871234', projectId: 'p1', trainingStatus: 'Completed', certificationStatus: 'Yes', interviewStatus: 'Scheduled', hiringStatus: 'Shortlisted' },
        { id: 'can2', name: 'Siva', email: 'siva@rrtech.com', phone: '987871234', projectId: 'p1', trainingStatus: 'In Progress', certificationStatus: 'No', interviewStatus: 'Pending', hiringStatus: 'Candidate Sourced' },
        { id: 'can3', name: 'Prudvi', email: 'prudvi@rrtech.com', phone: '9876543210', projectId: 'p2', trainingStatus: 'In Progress', certificationStatus: 'No', interviewStatus: 'Pending', hiringStatus: 'Shortlisted' },
        { id: 'can4', name: 'Sunny', email: 'sunny@rrtech.com', phone: '773094321', projectId: 'p2', trainingStatus: 'In Progress', certificationStatus: 'No', interviewStatus: 'Pending', hiringStatus: 'Candiate Sourced' },

    ],
    trainings: [
        { id: 't1', type: 'Computer Skills', vendorId: 'v1', duration: '4 Weeks', paymentType: 'RRTech Corp Pays', certRequired: 'Yes' },
        { id: 't2', type: 'Business Skills', vendorId: 'v1', duration: '2 Weeks', paymentType: 'Client Pays', certRequired: 'No' },
        { id: 't3', type: 'Logic Skills', vendorId: 'v2', duration: '3 Weeks', paymentType: 'Trainee Pays', certRequired: 'Yes' },
    ]
};
