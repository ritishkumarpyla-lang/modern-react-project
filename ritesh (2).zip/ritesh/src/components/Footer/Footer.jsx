import React from 'react';
import { NavLink } from 'react-router-dom';
import { Mail, Phone, MapPin, Globe, Github, Linkedin, Twitter } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const Footer = () => {
    const { user } = useAuth();
    const currentYear = new Date().getFullYear();

    const sections = [
        {
            title: 'Quick Links',
            links: [
                { label: 'Dashboard', path: '/dashboard' },
                { label: 'Projects', path: '/projects' },
                { label: 'Candidates', path: '/candidates' },
                { label: 'Reports', path: '/reports', role: 'Account Manager' },
            ].filter(l => !l.role || l.role === user?.role)
        },
        {
            title: 'Support',
            links: [
                { label: 'Help Center', path: '#' },
                { label: 'Terms of Service', path: '#' },
                { label: 'Privacy Policy', path: '#' },
                { label: 'Cookie Policy', path: '#' },
            ]
        }
    ];

    return (
        <footer className="bg-white border-t border-slate-200 pt-12 pb-8 px-6">
            <div className="max-w-7xl mx-auto">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
                    {/* Brand Section */}
                    <div className="space-y-4">
                        <div className="flex items-center gap-2 font-bold text-xl">
                            <div className="bg-primary-600 px-3 py-1 rounded-lg flex items-center justify-center text-white">
                                RRTech
                            </div>
                            <span className="text-slate-900">Corp</span>
                        </div>
                        <p className="text-slate-500 text-sm leading-relaxed max-w-xs">
                            Empowering enterprise growth through innovative management solutions and streamlined talent workflows.
                        </p>
                        <div className="flex items-center gap-4 text-slate-400">
                            <a href="#" className="hover:text-primary-600 transition-colors"><Twitter size={18} /></a>
                            <a href="#" className="hover:text-primary-600 transition-colors"><Linkedin size={18} /></a>
                            <a href="#" className="hover:text-primary-600 transition-colors"><Github size={18} /></a>
                        </div>
                    </div>

                    {/* Links Sections */}
                    {sections.map((section) => (section.links.length > 0 &&
                        <div key={section.title} className="space-y-4">
                            <h4 className="font-bold text-slate-900 uppercase tracking-wider text-xs">{section.title}</h4>
                            <ul className="space-y-2">
                                {section.links.map((link) => (
                                    <li key={link.label}>
                                        <NavLink
                                            to={link.path}
                                            className="text-slate-500 hover:text-primary-600 text-sm transition-colors"
                                        >
                                            {link.label}
                                        </NavLink>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    ))}

                    {/* Contact Section */}
                    <div className="space-y-4">
                        <h4 className="font-bold text-slate-900 uppercase tracking-wider text-xs">Contact Us</h4>
                        <ul className="space-y-3">
                            <li className="flex items-start gap-3 text-slate-500 text-sm">
                                <MapPin size={18} className="text-primary-600 shrink-0 mt-0.5" />
                                <span>Madhapur, Hyderabad, Telangana, India</span>
                            </li>
                            <li className="flex items-center gap-3 text-slate-500 text-sm">
                                <Phone size={18} className="text-primary-600 shrink-0" />
                                <span>+91 987 456 5467</span>
                            </li>
                            <li className="flex items-center gap-3 text-slate-500 text-sm">
                                <Mail size={18} className="text-primary-600 shrink-0" />
                                <span>support@rrtech.com</span>
                            </li>
                        </ul>
                    </div>
                </div>

                {/* Bottom Bar */}
                <div className="pt-8 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-4">
                    <p className="text-slate-400 text-sm text-center md:text-left">
                        © {currentYear} RRTech Corp. All rights reserved.
                    </p>
                    <div className="flex items-center gap-6 text-sm text-slate-400">
                        <span className="flex items-center gap-1.5 hover:text-slate-600 cursor-pointer transition-colors">
                            <Globe size={14} />
                            English (US)
                        </span>
                        <span className="hover:text-slate-600 cursor-pointer transition-colors">Privacy</span>
                        <span className="hover:text-slate-600 cursor-pointer transition-colors">Security</span>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
