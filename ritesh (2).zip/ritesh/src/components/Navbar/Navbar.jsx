import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { LogOut, Home, LayoutDashboard, Users, Briefcase, GitBranch, Truck, GraduationCap, ClipboardList, PieChart } from 'lucide-react';

const Navbar = () => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    const menuItems = [
        { label: 'Dashboard', path: '/dashboard', icon: LayoutDashboard, roles: ['Account Manager', 'Client'] },
        { label: 'Clients', path: '/clients', icon: Users, roles: ['Account Manager'] },
        { label: 'Projects', path: '/projects', icon: Briefcase, roles: ['Account Manager', 'Client'] },
        { label: 'Workflow Builder', path: '/workflow-builder', icon: GitBranch, roles: ['Account Manager'] },
        { label: 'Vendors', path: '/vendors', icon: Truck, roles: ['Account Manager'] },
        { label: 'Candidates', path: '/candidates', icon: GraduationCap, roles: ['Account Manager', 'Client'] },
        { label: 'Trainings', path: '/trainings', icon: ClipboardList, roles: ['Account Manager'] },
        { label: 'Reports', path: '/reports', icon: PieChart, roles: ['Account Manager'] },
    ];

    return (
        <nav className="fixed top-0 left-0 right-0 bg-white shadow-sm z-50 px-6 h-16 flex items-center justify-between border-b border-slate-200">
            <div className="flex items-center gap-8">
                <NavLink to="/dashboard" className="flex items-center gap-2 font-bold text-xl hover:opacity-90 transition-opacity">
                    <div className="bg-primary-600 px-3 py-1 rounded-lg flex items-center justify-center text-white">
                        RRTech
                    </div>
                    <span className="text-slate-900">Corp</span>
                </NavLink>

                <div className="hidden lg:flex items-center gap-1">
                    {menuItems.filter(item => item.roles.includes(user?.role)).map((item) => (
                        <NavLink
                            key={item.path}
                            to={item.path}
                            className={({ isActive }) => `flex items-center gap-2 px-3 py-2 rounded-md transition-colors text-sm font-medium ${isActive ? 'bg-primary-50 text-primary-600' : 'text-slate-600 hover:bg-slate-50'
                                }`}
                        >
                            <item.icon size={18} />
                            {item.label}
                        </NavLink>
                    ))}
                </div>
            </div>

            <div className="flex items-center gap-4">
                <div className="text-right hidden sm:block">
                    <p className="text-sm font-semibold text-slate-900">{user?.name}</p>
                    <p className="text-xs text-slate-500 uppercase tracking-wider font-bold">{user?.role}</p>
                </div>
                <button
                    onClick={handleLogout}
                    className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors"
                    title="Logout"
                >
                    <LogOut size={20} />
                </button>
            </div>
        </nav>
    );
};

export default Navbar;
