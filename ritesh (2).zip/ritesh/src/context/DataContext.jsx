import React, { createContext, useContext, useState } from 'react';
import { mockData } from '../services/mockData';

const DataContext = createContext();

export const DataProvider = ({ children }) => {
    const [data, setData] = useState(mockData);

    const addClient = (client) => {
        setData(prev => ({
            ...prev,
            clients: [...prev.clients, { ...client, id: `c${Date.now()}` }]
        }));
    };

    const updateClient = (id, updatedClient) => {
        setData(prev => ({
            ...prev,
            clients: prev.clients.map(c => c.id === id ? { ...c, ...updatedClient } : c)
        }));
    };

    const deleteClient = (id) => {
        setData(prev => ({
            ...prev,
            clients: prev.clients.filter(c => c.id !== id)
        }));
    };

    // Generic methods for other entities can be added here

    return (
        <DataContext.Provider value={{ data, addClient, updateClient, deleteClient }}>
            {children}
        </DataContext.Provider>
    );
};

export const useData = () => useContext(DataContext);
