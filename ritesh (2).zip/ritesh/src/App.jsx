import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { DataProvider } from './context/DataContext';
import Layout from './components/Layout/Layout';
import Login from './pages/Login/Login';
import Dashboard from './pages/Dashboard/Dashboard';
import Clients from './pages/Clients/Clients';
import Projects from './pages/Projects/Projects';
import Vendors from './pages/Vendors/Vendors';
import Trainings from './pages/Trainings/Trainings';
import Candidates from './pages/Candidates/Candidates';
import Reports from './pages/Reports/Reports';
import WorkflowBuilder from './pages/WorkflowBuilder/WorkflowBuilder';

function App() {
  return (
    <Router>
      <AuthProvider>
        <DataProvider>
          <Routes>
            <Route path="/login" element={<Login />} />

            <Route path="/" element={<Layout />}>
              <Route index element={<Navigate to="/dashboard" replace />} />
              <Route path="dashboard" element={<Dashboard />} />
              <Route path="clients" element={<Clients />} />
              <Route path="projects" element={<Projects />} />
              <Route path="vendors" element={<Vendors />} />
              <Route path="candidates" element={<Candidates />} />
              <Route path="trainings" element={<Trainings />} />
              <Route path="workflow-builder" element={<WorkflowBuilder />} />
              <Route path="reports" element={<Reports />} />
            </Route>

            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </DataProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;
